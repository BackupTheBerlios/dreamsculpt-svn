#include <arpeggiator.h>
#include "alsamidi.h"

Arpeggiator::Arpeggiator(int note, int velocity, int channel, int tempo, QList<ArpNote> arp) {
	this->note = note;
	this->velocity = velocity;
	this->channel = channel;
	this->tempo = tempo;
	this->pattern = arp;

	cnote = 0;

	// Trigger first note
	mid->noteOn(channel, note + pattern[cnote].note, velocity);
	
	// Calculate time until next next note change
	nextnote = calcNextNote();
}

double Arpeggiator::calcNextNote() {
	double nlen = 60.0 / tempo * pattern[cnote].length;
	return tme() + nlen;
}

void Arpeggiator::update() {
	if(tme() < nextnote)
		return;

	mid->noteOff(channel, note + pattern[cnote].note);

	if(cnote + 1 >= pattern.size())
		cnote = 0;
	else
		cnote++;

	mid->noteOn(channel, note + pattern[cnote].note, velocity);
	nextnote = calcNextNote();
}

Arpeggiator::~Arpeggiator() {
	// Aaah... Dying... I will take everyone with me!
	mid->noteOff(channel, pattern[cnote].note + note);
}
