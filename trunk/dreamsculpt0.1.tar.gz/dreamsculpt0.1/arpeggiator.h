#ifndef DREAMSCULPT_ARPEGGIATOR_H
#define DREAMSCULPT_ARPEGGIATOR_H 1
#include <sys/time.h>
#include <QList>

inline double tme() {
	struct timeval now;
	gettimeofday(&now, 0);
	return now.tv_sec + (now.tv_usec / 1000000.0);
}

struct ArpNote {
	double length;
	int note;
};

class Arpeggiator {
	private:
	int note;
	int velocity;
	int channel;
	int cnote;

	double nextnote;

	double timer;

	int tempo;
	QList <ArpNote> pattern;
	double calcNextNote();

	public:
	Arpeggiator(int note, int velocity, int channel, int tempo, QList<ArpNote> arp);
	void update();
	int getNote() { return note; }
	~Arpeggiator();

};


#endif
